'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var widgets = require('jupyter-js-widgets');

var WidgetManager = exports.WidgetManager = function (_widgets$ManagerBase) {
    _inherits(WidgetManager, _widgets$ManagerBase);

    function WidgetManager(kernel, el) {
        _classCallCheck(this, WidgetManager);

        var _this = _possibleConstructorReturn(this, (WidgetManager.__proto__ || Object.getPrototypeOf(WidgetManager)).call(this));

        _this.kernel = kernel;
        _this.el = el;

        // Create a comm manager shim
        _this.commManager = new widgets.shims.services.CommManager(kernel);

        // Register the comm target
        _this.commManager.register_target(_this.comm_target_name, _this.handle_comm_open.bind(_this));
        return _this;
    }

    _createClass(WidgetManager, [{
        key: 'display_view',
        value: function display_view(msg, view, options) {
            var that = this;
            return Promise.resolve(view).then(function (view) {
                that.el.appendChild(view.el);
                view.trigger('displayed');
                view.on('remove', function () {
                    console.log('view removed', view);
                });
                return view;
            });
        }
    }, {
        key: '_create_comm',
        value: function _create_comm(targetName, id, metadata) {
            return this.commManager.new_comm(targetName, metadata, id);
        }
    }, {
        key: '_get_comm_info',
        value: function _get_comm_info() {
            return Promise.resolve({});
        }
    }]);

    return WidgetManager;
}(widgets.ManagerBase);